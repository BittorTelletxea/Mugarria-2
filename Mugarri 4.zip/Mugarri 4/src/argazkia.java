import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;

public class argazkia implements ActionListener {
    private JComboBox<String> combo;
    private JLabel Argazkia;

    public argazkia(JComboBox<String> combo, JLabel Argazkia) {
        this.combo = combo;
        this.Argazkia = Argazkia;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Argazkien izena hartzen du
        String Imagename = (String) combo.getSelectedItem();

        // Cargar la imagen correspondiente
        ImageIcon imageIcon = new ImageIcon("./argazkiak/" + Imagename);
        Image foto = imageIcon.getImage();
        Image newfoto = foto.getScaledInstance(250, 250, Image.SCALE_SMOOTH);
        ImageIcon newimageIcon = new ImageIcon(newfoto);

        Argazkia.setIcon(newimageIcon);//Label-ean argazkia jarri
    }
}