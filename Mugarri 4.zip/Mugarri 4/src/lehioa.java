import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;

public class lehioa extends JFrame implements ActionListener {

    private JComboBox <String> aukerak;

    private static final String karpeta = "argazkiak";

    private ImageIcon imageIcon;

    private JLabel labelFoto;

    private JPanel panelMain;

    private JCheckBox checkBox;

    private JTextArea textArea;

    private JButton save;

    public lehioa() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Mugarria4");
        setSize(500, 500);

        this.panelMain = new JPanel();

        this.aukerak = new JComboBox<String>();
        load_combo();
        this.aukerak.addActionListener(new argazkia(this.aukerak, this.labelFoto));

        this.checkBox = new JCheckBox("Save your comment",true);

        this.textArea = new JTextArea();
        this.textArea.setPreferredSize(new Dimension(50, 10));

        this.checkBox = new JCheckBox("Save your comment",true);

        this.save = new JButton("SAVE");

        //Eventos

        this.save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedImage = (String) aukerak.getSelectedItem();
                String comment = textArea.getText();
                OutputStream outputStream= null;

                if (checkBox.isSelected()) {
                    String fileName = selectedImage.substring(0, selectedImage.lastIndexOf(".")) + ".txt";
                    try {
                        outputStream = new FileOutputStream(fileName, true);
                        outputStream.write(comment.getBytes());
                        outputStream.write("\n".getBytes());

                    }
                    catch (FileNotFoundException ex) {
                        throw new RuntimeException(ex);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }finally {
                        try {
                            outputStream.close();
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            }
        });


        //elementuak panelean jarri

        this.panelMain.setLayout(new BoxLayout ( this.panelMain, BoxLayout.Y_AXIS));
        this.panelMain.add(this.aukerak);
        this.panelMain.add(this.labelFoto);
        this.panelMain.add(this.checkBox);
        this.panelMain.add(this.textArea);
        this.panelMain.add(this.save);
        this.add(panelMain);


    }


    private void load_combo() {
        File carpeta = new File("./" + this.karpeta);
        File[] files = carpeta.listFiles();
        for (File file : files) {
            if (file.isFile()) {
                aukerak.addItem(file.getName());
            }
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {

    }
    public static void main(String[] args) {

        // Ask for password
        String input = JOptionPane.showInputDialog(null, "Pasahitza sartu:");

        // Check password
        if (input == null || !input.equals("damocles")) {
            ImageIcon image = new ImageIcon("./Egoitz.jpg");

            JOptionPane.showMessageDialog(null, "Pssahitza gaizki jarri duzu, Egoitz", "Error", JOptionPane.INFORMATION_MESSAGE, image);
            System.exit(0);
        }

        // Password is correct, continue with the main window
        lehioa ventana = new lehioa();
        ventana.setVisible(true);

        ventana.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                JOptionPane.showMessageDialog(null, "Bye!");
            }
        });
    }
}
