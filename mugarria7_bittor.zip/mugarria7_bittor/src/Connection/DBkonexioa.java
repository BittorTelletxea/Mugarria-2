import java.sql.*;

public class DBkonexioa {

    private Connection conexion;

    private String link = "jdbc:mysql://10.14.1.127/programazioa";
    private final static String erabiltzailea = "erabiltzaile";
    private final static String pasahitza = "erabiltzaile";

    // Constructor de la clase
    public DBkonexioa() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(link, erabiltzailea, pasahitza);
            System.out.println("Connection succesfuly");

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Errorea konexioa egitean " + e.getMessage());
            throw new SQLException("Errorea konexioa egitean " + e.getMessage());
        }
    }


    public ResultSet select(String consulta) throws SQLException {
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            statement = this.conexion.createStatement();
            resultSet = statement.executeQuery(consulta);
        } catch (SQLException e) {
            System.out.println("Errorea kontsulta egitean: " + e.getMessage());
            throw e;
        } finally {
            System.out.println("Select-a ondo");
        }
        return resultSet;
    }

    public void update(String query) {
        Statement statement = null;
        try {
            statement = conexion.createStatement();
            int rows = statement.executeUpdate(query);
            System.out.println(rows + " rows updated");
        } catch (SQLException e) {
            throw new RuntimeException("Errorea aktualizatzean " + e.getMessage(), e);
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException e) {
                throw new RuntimeException("Error closing resources: " + e.getMessage(), e);
            }
        }
    }


    public void cerrar()  {
        try {
            this.conexion.close();
        } catch (SQLException e) {
            System.out.println("Errorea konexioa ixterakoan");;
        }
        System.out.println("Konexioa off");
    }


}
