package Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EventHandler implements ActionListener {
    private IPictureViewer IPictureViewer;
    public EventHandler(IPictureViewer iPictureViewer){
        this.IPictureViewer = iPictureViewer;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        JButton JButton = (JButton) e.getSource();
        String JButton_text = JButton.getText();
        String JButton_name = JButton.getName();
        switch (JButton_text){
            case "AWARD":
                this.IPictureViewer.award();
                break;
            case "REMOVE":
                this.IPictureViewer.remove();
            default:{
                System.out.println("Evenhandler errorea");
            }
        }
    }
}

