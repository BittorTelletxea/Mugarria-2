package Model;

import java.util.ArrayList;

public class Photographer {
    private int ID;
    private String izena;
    private boolean award;


    public Photographer(boolean award, int ID, String izena) {
        this.award = award;
        this.ID = ID;
        this.izena = izena;
    }

    public void setPhotographerId(int ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.izena = name;
    }

    public int getPhotographerId() {
        return ID;
    }
    public String getName() {
        return izena;
    }
    public void setAwarded(boolean awarded) {
        this.award = award;
    }
    public boolean isAwarded() {
        return award;
    }
}
